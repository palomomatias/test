package trabajoPractico;

public class EjercicioUno {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=0;
		int multiplicacion;
		num1=+2;
		System.out.println(num1);
		multiplicacion=num1*2;
		System.out.println(multiplicacion);
	}

}
