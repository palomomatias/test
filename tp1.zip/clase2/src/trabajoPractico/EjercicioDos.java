package trabajoPractico;

public class EjercicioDos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num1=4;
		int num2=5;
		int producto;
		int suma;
		producto=num1*num2;
		suma=num1+num2;
		System.out.println("La suma es "+suma);
		System.out.println("El producto es "+producto);
	}

}
